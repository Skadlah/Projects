/**
  ******************************************************************************
  * @file    ads1115.h
  * @brief   Header file for ADS1115 ADC driver and PT100 temperature calculation.
  ******************************************************************************
  */

#ifndef ADS1115_H
#define ADS1115_H

#include "main.h"   // Pulls in the correct HAL header for this target (F1)

/* ---------- I2C device address (ADDR pin -> GND) ---------- */
#define ADS1115_I2C_ADDR        (0x48 << 1)   // 7-bit 0x48, pre-shifted for HAL

/* ---------- Register map ---------- */
#define ADS1115_REG_CONVERSION  0x00
#define ADS1115_REG_CONFIG      0x01

/* ---------- Config register bitfields ---------- */
#define ADS1115_OS_SINGLE       (1 << 15)

#define ADS1115_MUX_AIN0        (0x4 << 12)
#define ADS1115_MUX_AIN1        (0x5 << 12)
#define ADS1115_MUX_AIN2        (0x6 << 12)
#define ADS1115_MUX_AIN3        (0x7 << 12)

#define ADS1115_PGA_6144        (0x0 << 9)   // +/-6.144V, 187.5uV/bit
#define ADS1115_PGA_4096        (0x1 << 9)   // +/-4.096V, 125uV/bit
#define ADS1115_PGA_2048        (0x2 << 9)   // +/-2.048V, 62.5uV/bit
#define ADS1115_PGA_1024        (0x3 << 9)   // +/-1.024V, 31.25uV/bit
#define ADS1115_PGA_512         (0x4 << 9)   // +/-0.512V, 15.625uV/bit  <-- used
#define ADS1115_PGA_256         (0x5 << 9)   // +/-0.256V, 7.8125uV/bit

#define ADS1115_MODE_SINGLE     (1 << 8)

#define ADS1115_DR_128SPS       (0x4 << 5)

#define ADS1115_COMP_DISABLE    (0x3)

/* ---------- Excitation circuit constants (YOUR HARDWARE) ---------- */
#define ADS1115_R_BIAS_OHMS     999.0f     // Pull-up resistor
#define ADS1115_VCC_VOLTS       3.300f      // Supply feeding the divider

/* ---------- Gain in use: must match ADS1115_PGA_512 above ---------- */
#define ADS1115_LSB_VOLTS       0.000015625f  // 15.625uV per bit at PGA_512

//#define ADS1115_LSB_VOLTS          0.0000625f
//#define ADS1115_LSB_VOLTS   0.000125f

/* ---------- PT100 constants (IEC 60751 Callendar-Van Dusen, A/B only) --- */
#define PT100_R0                100.0f
// #define PT100_R0                1000.0f --> NEED TO CHANGE
#define PT100_A                 3.9083e-3f
#define PT100_B                 -5.775e-7f

/* ---------- Lead resistance compensation ----------
 * MEASURE THIS: short the PT100's sensor-end terminals together (red
 * shorted to both whites, right at the sensor), then read back the
 * apparent resistance ADS1115_GetTemp computes at 0 ohms RTD resistance.
 * Whatever nonzero resistance you see IS your lead resistance -- put it
 * here. Currently 0.0 = uncompensated, DO NOT trust readings until set.
 */
// #define PT100_LEAD_RESISTANCE_OHMS   0.0f
#define PT100_LEAD_RESISTANCE_OHMS   3.3f // ----> CHANGED HERE 0.0f to 3.3f

/* ---------- Function prototypes ---------- */
HAL_StatusTypeDef ADS1115_Init(I2C_HandleTypeDef *hi2c);
float ADS1115_GetTemp(I2C_HandleTypeDef *hi2c, uint8_t channel);

/* Optional: raw resistance readout, useful for the lead-resistance
 * shorting test and for calibration/debugging without going through
 * the temperature conversion. */
float ADS1115_GetResistance(I2C_HandleTypeDef *hi2c, uint8_t channel);
int16_t ADS1115_ReadADC_SingleEnded(
    I2C_HandleTypeDef *hi2c,
    uint8_t channel
);

float ADS1115_Get_PT100_Temperature(
    I2C_HandleTypeDef *hi2c,
    uint8_t channel,
    float v_supply,
    float r_ref,
    float offset
);
#endif /* ADS1115_H */
