/*
 * buzzer.h
 *
 *  Created on: 24-Oct-2026
 *      Author: Milind
 */

#ifndef BUZZER_H
#define BUZZER_H

#include "main.h"

/* Buzzer Hardware Mapping */
#define BUZZER_Pin       GPIO_PIN_0
#define BUZZER_GPIO_Port GPIOB

/* Function Prototypes */
void Buzzer_Init(void);
void Buzzer_ShortBeep(void);
void Buzzer_LongBeep(void);

#endif /* BUZZER_H */
