/* Core/Inc/compressor.h */
#ifndef COMPRESSOR_H
#define COMPRESSOR_H

#include "main.h"

void Compressor_On(void);
void Compressor_Off(void);

#endif
