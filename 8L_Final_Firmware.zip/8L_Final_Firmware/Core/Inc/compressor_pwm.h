/* Core/Inc/compressor_pwm.h */
#ifndef COMPRESSOR_PWM_H
#define COMPRESSOR_PWM_H

#include "main.h"

void Compressor_PWM_Init(void);
void Compressor_PWM_Control_Handler(float current_computed_temp, float set_temperature);

#endif
