#ifndef HEATER_H
#define HEATER_H

#include <stdint.h>

void Heater_Init(void);
void Heater_Control_Handler(float current_temp, float set_temp);
void Heater_On(void);
void Heater_Off(void);

extern volatile int PID_Heater_Status;
extern volatile int Normal_Heater_Status;
extern volatile uint16_t PWM_Duty;

#endif
