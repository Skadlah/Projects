/* Core/Inc/led_indicator.h */
#ifndef LED_INDICATOR_H
#define LED_INDICATOR_H

#include "main.h"

void LED_Indicator_Init(void);
void LED_Set_Heater(uint8_t state);
void LED_Set_Compressor(uint8_t state);
void LED_All_Off(void);

#endif
