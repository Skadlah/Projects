/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
/* Power State Enum Definition */
typedef enum {
    SYSTEM_RUNNING = 0,
    SYSTEM_LOCKED_OFF = 1
} Power_State_t;

typedef enum {
    M_RUNNING = 0,
    M_MENU_SELECT,
    M_VALUE_EDIT,
    M_SAVE_EXIT_TRIGGERED
} Menu_State_t;
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
extern int Current_Temp;
extern int Set_Temp;
extern volatile float Hysteresis_Range;

extern volatile int F3_Delay_Min;
extern volatile int F4_Calib_Val;
extern volatile int PID_Enable;

extern int Comp_State;
extern volatile int cycle_stage;
extern int Heater_State;

extern volatile int PID_Heater_Status;
extern volatile int Normal_Heater_Status;

extern volatile int Compressor_PWM_Duty;
extern volatile int Compressor_PWM_Mode;
extern volatile int Compressor_Running;

extern volatile uint16_t debug_rtd_raw_bits;
extern volatile float debug_rtd_resistance_ohms;
extern volatile float Heater_Current_Amps;

extern Power_State_t current_pwr_state;
/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define BTN_DEC_Pin GPIO_PIN_2
#define BTN_DEC_GPIO_Port GPIOA

#define BTN_S_Pin GPIO_PIN_3
#define BTN_S_GPIO_Port GPIOA

#define MAX7219_CS_GPIO_Port   GPIOB
#define MAX7219_CS_Pin   GPIO_PIN_1

//#define BTN_INC_Pin GPIO_PIN_14
#define BTN_INC_Pin GPIO_PIN_12
#define BTN_INC_GPIO_Port GPIOB

#define BTN_PWR_Pin GPIO_PIN_13
#define BTN_PWR_GPIO_Port GPIOB

#define HEATER_LED_Pin GPIO_PIN_11
#define HEATER_LED_GPIO_Port GPIOA

/*
#define COMP_LED_Pin GPIO_PIN_12
#define COMP_LED_GPIO_Port GPIOA
#define COMP_RELAY__Pin GPIO_PIN_5
#define COMP_RELAY__GPIO_Port GPIOB

// TM1637 4-digit display: pins used by the existing tm1637.c driver -----------> sk
#define TM1637_CLK_GPIO_Port GPIOB
#define TM1637_CLK_Pin       GPIO_PIN_10
#define TM1637_DIO_GPIO_Port GPIOB
#define TM1637_DIO_Pin       GPIO_PIN_11
*/


/* USER CODE BEGIN Private defines */


/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
