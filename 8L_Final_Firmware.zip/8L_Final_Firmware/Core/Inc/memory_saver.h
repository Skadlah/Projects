/* Core/Inc/memory_saver.h */
#ifndef MEMORY_SAVER_H
#define MEMORY_SAVER_H

#include "main.h"

/* STM32F103C8T6 Page 63 (Last Page of 64KB Flash: 0x0800FC00) */
#define FLASH_SAVE_ADDR  0x0800FC00

void Flash_Save_All_Settings(void);
void Flash_Read_All_Settings(void);

#endif
