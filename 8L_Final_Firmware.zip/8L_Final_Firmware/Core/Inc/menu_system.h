/* Core/Inc/menu_system.h */
#ifndef MENU_SYSTEM_H
#define MENU_SYSTEM_H

#include "main.h"

void Menu_System_Process(void);
void Main_Buttons_Driver_Process(void);
void Check_Temp_View_Timeout(void);

#endif
