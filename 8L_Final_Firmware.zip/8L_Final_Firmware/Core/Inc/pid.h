#ifndef __PID_H
#define __PID_H

#include "main.h"

typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float Integral;
    float Last_Error;
} PID_TypeDef;

void PID_Init(PID_TypeDef *pid, float kp, float ki, float kd);
int PID_Compute(PID_TypeDef *pid, float setpoint, float current_val);

#endif /* __PID_H */
