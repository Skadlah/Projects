#ifndef TM1637_H
#define TM1637_H

#include "main.h"
#include <stdint.h>

void TM1637_Init(void);
void TM1637_DisplayOn(void);
void TM1637_DisplayOff(void);

void TM1637_DisplayNumber_Internal(int num);
void TM1637_DisplayTemp_Float(int temp_x10);
void TM1637_DisplayHysteresis(float hys_value);

void TM1637_Display_Menu_Item(uint8_t f_num, int val_x10, uint8_t is_decimal);
void TM1637_DisplaySegments(uint8_t seg0, uint8_t seg1, uint8_t seg2, uint8_t seg3);

#endif /* TM1637_H */
