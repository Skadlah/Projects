	/**
	  ******************************************************************************
	  * @file    ads1115.c
	  * @brief   Source file for ADS1115 ADC driver and PT100 temperature calculation.
	  ******************************************************************************
	  */

	/*
	 * ads1115.c
	 *
	 * See ads1115.h for circuit assumptions and calibration notes.
	 */

#include "ads1115.h"
#include <math.h>

#define ADS1115_TIMEOUT_MS   50
#define ADS1115_POLL_MAX     100

static uint16_t ADS1115_MuxForChannel(uint8_t channel)
	{
		switch (channel)
		{
			case 0:  return ADS1115_MUX_AIN0;
			case 1:  return ADS1115_MUX_AIN1;
			case 2:  return ADS1115_MUX_AIN2;
			case 3:  return ADS1115_MUX_AIN3;
			default: return ADS1115_MUX_AIN0;
		}
	}

	/* ---------------------------------------------------------------------
	 * ADS1115_Init
	 * Just confirms the device answers on the bus. Nothing to configure
	 * up front since every conversion is single-shot with its own config
	 * write (see ADS1115_ReadRaw).
	 * ------------------------------------------------------------------- */
	HAL_StatusTypeDef ADS1115_Init(I2C_HandleTypeDef *hi2c)
	{
		return HAL_I2C_IsDeviceReady(hi2c, ADS1115_I2C_ADDR, 5, ADS1115_TIMEOUT_MS);
	}

	/* ---------------------------------------------------------------------
	 * ADS1115_ReadRaw
	 * Triggers one single-shot conversion on the given mux port at
	 * PGA_512 or 2048 / 128SPS, polls the OS bit for completion, reads back the
	 * signed 16-bit result. Returns HAL_ERROR on any I2C failure or
	 * timeout waiting for conversion-ready.
	 * ------------------------------------------------------------------- */
static HAL_StatusTypeDef ADS1115_ReadRaw(I2C_HandleTypeDef *hi2c, uint16_t muxPort, int16_t *rawOut)
	{
		uint8_t txBuf[2];
		uint8_t rxBuf[2];
		uint16_t config;

		config = ADS1115_OS_SINGLE | muxPort | ADS1115_PGA_512 | ADS1115_MODE_SINGLE
		//config = ADS1115_OS_SINGLE | muxPort | ADS1115_PGA_2048 | ADS1115_MODE_SINGLE
				 | ADS1115_DR_128SPS | ADS1115_COMP_DISABLE;

		txBuf[0] = (uint8_t)(config >> 8);
		txBuf[1] = (uint8_t)(config & 0xFF);

		if (HAL_I2C_Mem_Write(hi2c, ADS1115_I2C_ADDR, ADS1115_REG_CONFIG, 1, txBuf, 2, ADS1115_TIMEOUT_MS) != HAL_OK)
			return HAL_ERROR;

		for (uint16_t i = 0; i < ADS1115_POLL_MAX; i++)
		{
			if (HAL_I2C_Mem_Read(hi2c, ADS1115_I2C_ADDR, ADS1115_REG_CONFIG, 1, rxBuf, 2, ADS1115_TIMEOUT_MS) != HAL_OK)
				return HAL_ERROR;

			if (rxBuf[0] & 0x80)   // OS bit set again = conversion done
				break;

			if (i == ADS1115_POLL_MAX - 1)
				return HAL_ERROR;  // Timed out waiting for conversion
		}

		if (HAL_I2C_Mem_Read(hi2c, ADS1115_I2C_ADDR, ADS1115_REG_CONVERSION, 1, rxBuf, 2, ADS1115_TIMEOUT_MS) != HAL_OK)
			return HAL_ERROR;

		*rawOut = (int16_t)((rxBuf[0] << 8) | rxBuf[1]);
		return HAL_OK;
	}

	/* ---------------------------------------------------------------------
	 * ADS1115_GetResistance
	 * Converts the AIN reading back through the divider equation to the
	 * PT100's apparent resistance, then subtracts the calibrated lead
	 * resistance. Use this directly (with PT100_LEAD_RESISTANCE_OHMS left
	 * at 0.0) to run the shorting test: short the sensor-end terminals,
	 * call this, and whatever it reports IS your lead resistance.
	 * ------------------------------------------------------------------- */
float ADS1115_GetResistance(I2C_HandleTypeDef *hi2c, uint8_t channel)
	{
		int16_t raw;
		uint16_t muxPort = ADS1115_MuxForChannel(channel);

		if (ADS1115_ReadRaw(hi2c, muxPort, &raw) != HAL_OK)
			return NAN;

		if (raw <= 0)
			return NAN;  // Open circuit / disconnected sensor

		float v_ain0 = (float)raw * ADS1115_LSB_VOLTS;

		if (v_ain0 >= ADS1115_VCC_VOLTS)
			return NAN;  // Shorted / invalid reading, would divide by ~0

		// Divider: V = VCC * R_pt100 / (R_BIAS + R_pt100)  =>  solve for R_pt100
		float r_measured = (ADS1115_R_BIAS_OHMS * v_ain0) / (ADS1115_VCC_VOLTS - v_ain0);

		float r_pt100 = r_measured - PT100_LEAD_RESISTANCE_OHMS;

		return r_pt100;
	}

	/* ---------------------------------------------------------------------
	 * ADS1115_GetTemp
	 * Inverts the IEC 60751 Callendar-Van Dusen quadratic (A/B terms only;
	 * the cubic correction below 0C is under ~0.03% here and not worth the
	 * extra iteration for a freezer application). Valid roughly -200..850C.
	 * ------------------------------------------------------------------- */
float ADS1115_GetTemp(I2C_HandleTypeDef *hi2c, uint8_t channel)
	{
		float r_pt100 = ADS1115_GetResistance(hi2c, channel);

		if (isnan(r_pt100))
			return NAN;

		// R0*(1 + A*T + B*T^2) = R  =>  quadratic in T, solve directly
		float a = PT100_R0 * PT100_B;
		float b = PT100_R0 * PT100_A;
		float c = PT100_R0 - r_pt100;

		float discriminant = (b * b) - (4.0f * a * c);
		if (discriminant < 0.0f)
			return NAN;

		float temp = (-b + sqrtf(discriminant)) / (2.0f * a);

		return temp;
	}
int16_t ADS1115_ReadADC_SingleEnded(
		I2C_HandleTypeDef *hi2c,
		uint8_t channel)
	{
		uint16_t config;

		switch (channel)
		{
			case 0:
				config = 0xC383;   // AIN0-GND, ±4.096V, 128SPS
				break;

			case 1:
				config = 0xD383;   // AIN1-GND
				break;

			case 2:
				config = 0xE383;   // AIN2-GND
				break;

			case 3:
				config = 0xF383;   // AIN3-GND
				break;

			default:
				return -32768;
		}

		uint8_t data[3];

		data[0] = ADS1115_REG_CONFIG;
		data[1] = (uint8_t)(config >> 8);
		data[2] = (uint8_t)(config & 0xFF);

		if (HAL_I2C_Master_Transmit(
				hi2c,
				ADS1115_I2C_ADDR,
				data,
				3,
				100) != HAL_OK)
		{
			return -32768;
		}

		HAL_Delay(10);

		uint8_t reg = ADS1115_REG_CONVERSION;

		if (HAL_I2C_Master_Transmit(
				hi2c,
				ADS1115_I2C_ADDR,
				&reg,
				1,
				100) != HAL_OK)
		{
			return -32768;
		}

		uint8_t raw[2];

		if (HAL_I2C_Master_Receive(
				hi2c,
				ADS1115_I2C_ADDR,
				raw,
				2,
				100) != HAL_OK)
		{
			return -32768;
		}

		return (int16_t)(((uint16_t)raw[0] << 8) | raw[1]);
	}
float ADS1115_Get_PT100_Temperature(
		I2C_HandleTypeDef *hi2c,
		uint8_t channel,
		float v_supply,
		float r_ref,
		float offset)
	{
		int16_t adc_val;

		adc_val = ADS1115_ReadADC_SingleEnded(
			hi2c,
			channel
		);

		if (adc_val == -32768)
		{
			return NAN;
		}

		if (adc_val <= 0)
		{
			return NAN;
		}

		/*
		 * PGA = ±4.096V
		 * 1 LSB = 125uV
		 */
		float voltage =
			(float)adc_val * 0.000125f;

		if (voltage <= 0.0f ||
			voltage >= v_supply)
		{
			return NAN;
		}

		/*
		 * Voltage divider:
		 *
		 * 3.3V
		 *  |
		 * 1k
		 *  |
		 *  +---- A0
		 *  |
		 * PT100
		 *  |
		 * GND
		 *
		 * Rpt100 = Vout * Rref / (Vcc - Vout)
		 */

		float pt100_resistance =
			(voltage * r_ref) /
			(v_supply - voltage);

		if (pt100_resistance <= 0.0f)
		{
			return NAN;
		}

		/*
		 * PT100 Callendar-Van Dusen
		 * R = R0(1 + A*T + B*T²)
		 */

		const float R0 = 100.0f;
		const float A  = 3.9083e-3f;
		const float B  = -5.775e-7f;

		float c =
			1.0f - (pt100_resistance / R0);

		float discriminant =
			(A * A) - (4.0f * B * c);

		if (discriminant < 0.0f)
		{
			return NAN;
		}

		float temperature =
			(-A + sqrtf(discriminant)) /
			(2.0f * B);

		return temperature + offset;
	}
