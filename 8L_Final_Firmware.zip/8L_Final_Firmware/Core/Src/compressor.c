
#include "compressor.h"
#include "main.h"

extern int Comp_State;
extern volatile int Compressor_Running;
extern volatile int Compressor_PWM_Duty;


/* =========================================================
   COMPRESSOR ON
   GPIO = HIGH (3.3V)
   ========================================================= */
void Compressor_On(void)
{
    HAL_GPIO_WritePin(
        COMP_RELAY__GPIO_Port,
        COMP_RELAY__Pin,
        GPIO_PIN_SET
    );

    Comp_State = 1;
    Compressor_Running = 1;
}


/* =========================================================
   COMPRESSOR OFF
   GPIO = LOW (0V)
   ========================================================= */
void Compressor_Off(void)
{
    HAL_GPIO_WritePin(
        COMP_RELAY__GPIO_Port,
        COMP_RELAY__Pin,
        GPIO_PIN_RESET
    );

    Comp_State = 0;
    Compressor_Running = 0;
    Compressor_PWM_Duty = 0;
}
