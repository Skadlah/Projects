/*
 * compressor_pwm.c
 *
 *  Created on: 25-Oct-2026
 *      Author: Milind
 */

#include "compressor_pwm.h"
#include "compressor.h"
#include "main.h"

extern TIM_HandleTypeDef htim2;

extern int Heater_State;
extern volatile int PID_Enable;

extern volatile int Compressor_PWM_Duty;
extern volatile int Compressor_PWM_Mode;
extern volatile int Compressor_Running;

extern volatile int cycle_stage;
extern volatile float Hysteresis_Range;

/* =========================================================
   F3 DELAY VARIABLES
   ========================================================= */

static uint32_t compressor_delay_start = 0;
static uint8_t compressor_delay_active = 0;


/* =========================================================
   INIT
   ========================================================= */

void Compressor_PWM_Init(void)
{
    /* PWM OFF */
    HAL_TIM_PWM_Stop(
        &htim2,
        TIM_CHANNEL_2
    );

    /* PWM = 0 */
    __HAL_TIM_SET_COMPARE(
        &htim2,
        TIM_CHANNEL_2,
        0
    );

    /* Normal compressor GPIO OFF */
    Compressor_Off();

    compressor_delay_start = 0;
    compressor_delay_active = 0;

    Compressor_PWM_Duty = 0;
    Compressor_PWM_Mode = 0;
    Compressor_Running = 0;

    /* Default 100% */
    cycle_stage = 1;
}


/* =========================================================
   PWM CONTROL
   ========================================================= */

void Compressor_PWM_Control_Handler(
    float current_temp,
    float set_temp)
{
    uint32_t now = HAL_GetTick();

    float compressor_on_temp =
        set_temp + Hysteresis_Range;


    /* =====================================================
       1. HEATER ON
       ===================================================== */

    if (Heater_State != 0)
    {
        HAL_TIM_PWM_Stop(
            &htim2,
            TIM_CHANNEL_2
        );

        __HAL_TIM_SET_COMPARE(
            &htim2,
            TIM_CHANNEL_2,
            0
        );

        Compressor_Off();

        Compressor_PWM_Duty = 0;
        Compressor_PWM_Mode = 0;

        compressor_delay_active = 0;
        compressor_delay_start = 0;

        return;
    }


    /* =====================================================
       2. TEMPERATURE LOW
       ===================================================== */

    if (current_temp < compressor_on_temp)
    {
        HAL_TIM_PWM_Stop(
            &htim2,
            TIM_CHANNEL_2
        );

        __HAL_TIM_SET_COMPARE(
            &htim2,
            TIM_CHANNEL_2,
            0
        );

        Compressor_Off();

        Compressor_PWM_Duty = 0;
        Compressor_PWM_Mode = 0;

        compressor_delay_active = 0;
        compressor_delay_start = 0;

        return;
    }


    /* =====================================================
       3. F3 DELAY
       ===================================================== */

    if (F3_Delay_Min > 0)
    {
        /* Start F3 timer */
        if (compressor_delay_active == 0)
        {
            compressor_delay_active = 1;
            compressor_delay_start = now;

            HAL_TIM_PWM_Stop(
                &htim2,
                TIM_CHANNEL_2
            );

            __HAL_TIM_SET_COMPARE(
                &htim2,
                TIM_CHANNEL_2,
                0
            );

            Compressor_Off();

            Compressor_PWM_Duty = 0;
            Compressor_PWM_Mode = 0;

            return;
        }


        /* Dynamic F3 delay */
        uint32_t delay_ms =
            (uint32_t)F3_Delay_Min * 60000UL;


        /* Still waiting */
        if ((now - compressor_delay_start) < delay_ms)
        {
            HAL_TIM_PWM_Stop(
                &htim2,
                TIM_CHANNEL_2
            );

            __HAL_TIM_SET_COMPARE(
                &htim2,
                TIM_CHANNEL_2,
                0
            );

            Compressor_Off();

            Compressor_PWM_Duty = 0;
            Compressor_PWM_Mode = 0;

            return;
        }
    }
    else
    {
        /* F3 = 0 -> immediate ON */
        compressor_delay_active = 0;
        compressor_delay_start = 0;
    }


    /* =====================================================
       4. COMPRESSOR GPIO ON
       ===================================================== */

    Compressor_On();


    /* =====================================================
       5. SELECT PWM
       ===================================================== */

    uint32_t pwm_value;

    switch (cycle_stage)
    {
        case 0:
            pwm_value = 500;
            break;

        case 1:
            pwm_value = 750;
            break;

        case 2:
            pwm_value = 999;
            break;

        default:
            cycle_stage = 2;
            pwm_value = 999;
            break;
    }


    /* =====================================================
       6. SET PWM
       ===================================================== */

    __HAL_TIM_SET_COMPARE(
        &htim2,
        TIM_CHANNEL_2,
        pwm_value
    );


    /* =====================================================
       7. START PWM
       ===================================================== */

    HAL_TIM_PWM_Start(
        &htim2,
        TIM_CHANNEL_2
    );


    /* =====================================================
       8. STATUS
       ===================================================== */

    Compressor_PWM_Duty = (int)pwm_value;
    Compressor_PWM_Mode = cycle_stage;
    Compressor_Running = 1;
}



