
	/* Core/Src/heater.c */

#include "heater.h"
#include "pid.h"
#include "main.h"

extern TIM_HandleTypeDef htim1;

extern int Heater_State;

/* F5 PID setting */
extern volatile int PID_Enable;
/* PID object - type must match pid.h */
extern PID_TypeDef heaterPID;

extern volatile int PID_Heater_Status;
extern volatile int Normal_Heater_Status;
extern volatile uint16_t PWM_Duty;

/* =========================================================
	  HEATER INITIALIZATIO
 ========================================================= */

void Heater_Init(void)
	{
		/* Start TIM1 CH1 PWM */
		HAL_TIM_PWM_Start(
			&htim1,
			TIM_CHANNEL_1
		);
		__HAL_TIM_MOE_ENABLE(&htim1);

		Heater_Off();
	}


/* =========================================================
 HEATER CONTROL
 ========================================================= */

void Heater_Control_Handler(float current_temp, float set_temp)
	{
		/* =====================================================
		   PID MODE
		   ===================================================== */

		if (PID_Enable != 0)
		{
			float pid_output;

			/* Normal heater status must be OFF in PID mode */
			Normal_Heater_Status = 0;

			pid_output = (float)PID_Compute(
				&heaterPID,
				set_temp,
				current_temp
			);

			/* Safety limit */
			if (pid_output < 0.0f)
			{
				pid_output = 0.0f;
			}

			if (pid_output > 1000.0f)
					{
						pid_output = 1000.0f;
					}

			/* Apply PWM */
			__HAL_TIM_SET_COMPARE(
				&htim1,
				TIM_CHANNEL_1,
				(uint16_t)pid_output
			);

			/* Debug PWM value */
			PWM_Duty = (uint16_t)pid_output;

			/* PID heater status */
			if (pid_output > 0.0f)
			{
				PID_Heater_Status = 1;
				Heater_State = 1;
			}
			else
			{
				PID_Heater_Status = 0;
				Heater_State = 0;
			}

			return;
		}


/* =====================================================
NORMAL HEATER MODE
===================================================== */

		/* PID status OFF */
		PID_Heater_Status = 0;

		if (current_temp < set_temp)
		{
			Heater_On();
		}
		else
		{
			Heater_Off();
		}
	}


/* =========================================================
 NORMAL HEATER ON
 ========================================================= */

void Heater_On(void)
	{
		__HAL_TIM_SET_COMPARE(
			&htim1,
			TIM_CHANNEL_1,
			1000
		);
		__HAL_TIM_MOE_ENABLE(&htim1);

		PWM_Duty = 1000;

		Heater_State = 1;

		Normal_Heater_Status = 1;
	}


	/* =========================================================
	   NORMAL HEATER OFF
	   ========================================================= */

void Heater_Off(void)
	{
		__HAL_TIM_SET_COMPARE(
			&htim1,
			TIM_CHANNEL_1,
			0
		);

		PWM_Duty = 0;

		Heater_State = 0;

		Normal_Heater_Status = 0;
	}
