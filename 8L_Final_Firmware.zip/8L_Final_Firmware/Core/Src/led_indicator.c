/* Core/Src/led_indicator.c */
#include "led_indicator.h"

void LED_Indicator_Init(void)
{
    LED_All_Off();
}

void LED_Set_Heater(uint8_t state)
{
    HAL_GPIO_WritePin(HEATER_LED_GPIO_Port, HEATER_LED_Pin, state ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void LED_Set_Compressor(uint8_t state)
{
    HAL_GPIO_WritePin(COMP_LED_GPIO_Port, COMP_LED_Pin, state ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void LED_All_Off(void)
{
    HAL_GPIO_WritePin(HEATER_LED_GPIO_Port, HEATER_LED_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(COMP_LED_GPIO_Port, COMP_LED_Pin, GPIO_PIN_RESET);
}
