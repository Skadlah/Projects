/* Core/Src/memory_saver.c */
#include "memory_saver.h"

extern int Set_Temp;
extern volatile float Hysteresis_Range;
extern volatile int F3_Delay_Min;
extern volatile int F4_Calib_Val;
extern volatile int PID_Enable;

#define FLASH_MAGIC_KEY 0xABCD1234

void Flash_Save_All_Settings(void)
{
    HAL_FLASH_Unlock();

    FLASH_EraseInitTypeDef EraseInitStruct;
    uint32_t PageError = 0;

    EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
    EraseInitStruct.PageAddress = FLASH_SAVE_ADDR;
    EraseInitStruct.NbPages     = 1;

    if (HAL_FLASHEx_Erase(&EraseInitStruct, &PageError) == HAL_OK)
    {
        uint32_t addr = FLASH_SAVE_ADDR;

        /* Write Magic Key */
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, FLASH_MAGIC_KEY);
        addr += 4;

        /* Write Set_Temp */
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint32_t)Set_Temp);
        addr += 4;

        /* Write Hysteresis_Range (converted to int x10) */
        int hyst_x10 = (int)(Hysteresis_Range * 10.0f + 0.5f);
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint32_t)hyst_x10);
        addr += 4;

        /* Write F3_Delay_Min */
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint32_t)F3_Delay_Min);
        addr += 4;

        /* Write F4_Calib_Val */
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint32_t)F4_Calib_Val);
        addr += 4;

        /* Write PID_Enable */
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint32_t)PID_Enable);
    }

    HAL_FLASH_Lock();
}

void Flash_Read_All_Settings(void)
{
    uint32_t addr = FLASH_SAVE_ADDR;

    uint32_t magic = *(__IO uint32_t*)addr;
    addr += 4;

    /* Check if settings were previously saved */
    if (magic == FLASH_MAGIC_KEY)
    {
        Set_Temp = (int)(*(__IO uint32_t*)addr);
        addr += 4;

        int hyst_x10 = (int)(*(__IO uint32_t*)addr);
        Hysteresis_Range = ((float)hyst_x10) / 10.0f;
        addr += 4;

        F3_Delay_Min = (int)(*(__IO uint32_t*)addr);
        addr += 4;

        F4_Calib_Val = (int)(*(__IO uint32_t*)addr);
        addr += 4;

        PID_Enable = (int)(*(__IO uint32_t*)addr);
    }
    else
    {
        /* Default Fallback Values */
        Set_Temp = 25;
        Hysteresis_Range = 0.5f;
        F3_Delay_Min = 3;
        F4_Calib_Val = 0;
        PID_Enable = 1;
    }
}
