
#include "main.h"
#include "menu_system.h"
#include "tm1637.h"
#include "memory_saver.h"
#include "buzzer.h"

extern int Set_Temp;
//extern float Hysteresis_Range;
extern volatile int F3_Delay_Min;
extern volatile int F4_Calib_Val;
extern volatile int PID_Enable;
extern int Current_Temp;
extern int Active_Heater_Status;
//extern int Normal_Heater_Status;
//extern int PID_Heater_Status;
extern Power_State_t current_pwr_state;

Menu_State_t menu_state = M_RUNNING;
uint8_t menu_index = 1;
uint32_t total_timeout_tick = 0;
uint32_t last_button_tick = 0;

uint8_t quick_view_active = 0;
uint32_t quick_view_start_tick = 0;

void TM1637_Display_PID_Status(int status)
{
    if(status == 1)
    {
        TM1637_DisplaySegments(0x00, 0x3F, 0x54, 0x00); // ON
    }
    else
    {
        //TM1637_DisplaySegments(0x00, 0x7E, 0x47, 0x47); // OFF
    	TM1637_DisplaySegments(0x00, 0x3F, 0x71, 0x71); // OFF
    }
}

void TM1637_DisplayMenuCode(uint8_t index)
{
    uint8_t digit = 0;
    switch(index)
    /*{
        case 1: digit = 0x30; break;   // 1
        case 2: digit = 0x6D; break;   // 2
        case 3: digit = 0x79; break;   // 3
        case 4: digit = 0x33; break;   // 4
        case 5: digit = 0x5B; break;   // 5
        default: digit = 0x30; break;
    }*/
    {
        case 1: digit = 0x06; break;   // Hex for '1'
        case 2: digit = 0x5B; break;   // Hex for '2'
        case 3: digit = 0x4F; break;   // Hex for '3'
        case 4: digit = 0x66; break;   // Hex for '4'
        case 5: digit = 0x6D; break;   // Hex for '5'
       default: digit = 0x06; break;
      }
    // TM1637_DisplaySegments(0x47, digit, 0x00, 0x00); // Shows 'F1', 'F2', etc.
    TM1637_DisplaySegments(0x71, digit, 0x00, 0x00);

}

void Menu_Auto_Save(void)
{
    Flash_Save_All_Settings();
    menu_state = M_RUNNING;
    TM1637_DisplayNumber_Internal(Current_Temp);
}

void Check_Temp_View_Timeout(void)
{
    if(quick_view_active)
    {
        if(HAL_GetTick() - quick_view_start_tick >= 3000)
        {
            quick_view_active = 0;
            TM1637_DisplayNumber_Internal(Current_Temp);
        }
    }
}

void Menu_System_Process(void)
{
    uint32_t tick = HAL_GetTick();

    /* Clamp Hysteresis Range */
    if (Hysteresis_Range > 10.0f) Hysteresis_Range = 10.0f;
    if (Hysteresis_Range < 0.1f)  Hysteresis_Range = 0.1f;

    /* Handle Manual Exit State */
        if (menu_state == M_SAVE_EXIT_TRIGGERED)
        {
            Menu_Auto_Save();
            return;
        }

    /* ================= MENU BUTTON (PA3) ================= */
    if (HAL_GPIO_ReadPin(BTN_S_GPIO_Port, BTN_S_Pin) == GPIO_PIN_SET)
    {
        HAL_Delay(50);
        if (HAL_GPIO_ReadPin(BTN_S_GPIO_Port, BTN_S_Pin) == GPIO_PIN_SET)
        {
            total_timeout_tick = tick;
            Buzzer_ShortBeep(); // ---> Function call for beeping the buzzer

            if (menu_state == M_RUNNING)
            {
                menu_state = M_MENU_SELECT;
                menu_index = 1;
                TM1637_DisplayMenuCode(menu_index);
            }
            else if (menu_state == M_MENU_SELECT)
            {
                menu_state = M_VALUE_EDIT;
                if (menu_index == 1) TM1637_DisplayNumber_Internal(Set_Temp);
                else if (menu_index == 2) TM1637_DisplayTemp_Float((int)(Hysteresis_Range * 10.0f + 0.5f));
                else if (menu_index == 3) TM1637_DisplayNumber_Internal(F3_Delay_Min);
                else if (menu_index == 4) TM1637_DisplayNumber_Internal(F4_Calib_Val);
                else if (menu_index == 5) TM1637_Display_PID_Status(PID_Enable);
            }
            else if (menu_state == M_VALUE_EDIT)
            {
                menu_state = M_SAVE_EXIT_TRIGGERED;
            }
            while (HAL_GPIO_ReadPin(BTN_S_GPIO_Port, BTN_S_Pin) == GPIO_PIN_SET);
            return;
        }
    }

    /* Auto Save After 5 Seconds */
    if ((menu_state != M_RUNNING) && ((tick - total_timeout_tick) > 5000))
    {
        Menu_Auto_Save();
        return;
    }

    uint8_t inc_pressed = (HAL_GPIO_ReadPin(BTN_INC_GPIO_Port, BTN_INC_Pin) == GPIO_PIN_SET);
    uint8_t dec_pressed = (HAL_GPIO_ReadPin(BTN_DEC_GPIO_Port, BTN_DEC_Pin) == GPIO_PIN_SET);

    /* ================= INC BUTTON (PB12) ================= */
    if (inc_pressed && !dec_pressed)
    {
        if ((tick - last_button_tick) > 200)
        {
            last_button_tick = tick;
            total_timeout_tick = tick;

            Buzzer_ShortBeep(); // ---> Added function

            if (menu_state == M_RUNNING)
            {
                quick_view_active = 1;
                quick_view_start_tick = tick;
                TM1637_DisplayNumber_Internal(Set_Temp);
            }
            else if (menu_state == M_MENU_SELECT)
            {
                menu_index++;
                if (menu_index > 5) menu_index = 1;
                TM1637_DisplayMenuCode(menu_index);
            }
            else if (menu_state == M_VALUE_EDIT)
            {
                if (menu_index == 1 && Set_Temp < 100) Set_Temp++;
                else if (menu_index == 2 && Hysteresis_Range < 10.0f) Hysteresis_Range += 0.1f;
                else if (menu_index == 3 && F3_Delay_Min < 10) F3_Delay_Min++;
                else if (menu_index == 4 && F4_Calib_Val < 10) F4_Calib_Val++;
                else if (menu_index == 5) PID_Enable = 1;

                /* Refresh Displays */
                if (menu_index == 1) TM1637_DisplayNumber_Internal(Set_Temp);
                else if (menu_index == 2) TM1637_DisplayTemp_Float((int)(Hysteresis_Range * 10.0f + 0.5f));
                else if (menu_index == 3) TM1637_DisplayNumber_Internal(F3_Delay_Min);
                else if (menu_index == 4) TM1637_DisplayNumber_Internal(F4_Calib_Val);
                else if (menu_index == 5) TM1637_Display_PID_Status(PID_Enable);
            }
        }
    }
    /* ================= DEC BUTTON (PA2) ================= */
    else if (dec_pressed && !inc_pressed)
    {
        if ((tick - last_button_tick) > 200)
        {
            last_button_tick = tick;
            total_timeout_tick = tick;
            Buzzer_ShortBeep();  // ---- Call buzzer beep function

            if (menu_state == M_RUNNING)
            {
                quick_view_active = 1;
                quick_view_start_tick = tick;
                TM1637_DisplayHysteresis(Hysteresis_Range);
            }
            else if (menu_state == M_MENU_SELECT)
            {
                if (menu_index > 1) menu_index--;
                else menu_index = 5;
                TM1637_DisplayMenuCode(menu_index);
            }
            else if (menu_state == M_VALUE_EDIT)
            {
                if (menu_index == 1 && Set_Temp > -100) Set_Temp--;
                else if (menu_index == 2 && Hysteresis_Range > 0.1f) Hysteresis_Range -= 0.1f;
                else if (menu_index == 3 && F3_Delay_Min > 1) F3_Delay_Min--;
                else if (menu_index == 4 && F4_Calib_Val > -10) F4_Calib_Val--;
                else if (menu_index == 5) PID_Enable = 0;

                /* Refresh Displays */
                if (menu_index == 1) TM1637_DisplayNumber_Internal(Set_Temp);
                else if (menu_index == 2) TM1637_DisplayTemp_Float((int)(Hysteresis_Range * 10.0f + 0.5f));
                else if (menu_index == 3) TM1637_DisplayNumber_Internal(F3_Delay_Min);
                else if (menu_index == 4) TM1637_DisplayNumber_Internal(F4_Calib_Val);
                else if (menu_index == 5) TM1637_Display_PID_Status(PID_Enable);
            }
        }
    }
    else
    {
        last_button_tick = 0;
    }
}

void Main_Buttons_Driver_Process(void)
{
    static uint8_t power_pressed = 0;

    /* Touch = GPIO_PIN_SET (Active HIGH) */
    if (HAL_GPIO_ReadPin(BTN_PWR_GPIO_Port, BTN_PWR_Pin) == GPIO_PIN_SET)
    {
        if (power_pressed == 0)
        {
            HAL_Delay(50); // Debounce
            if (HAL_GPIO_ReadPin(BTN_PWR_GPIO_Port, BTN_PWR_Pin) == GPIO_PIN_SET)
            {
                power_pressed = 1;
                Buzzer_LongBeep(); // ----> Added for power button when power button get press
                if (current_pwr_state == SYSTEM_LOCKED_OFF)
                {
                    current_pwr_state = SYSTEM_RUNNING;
                }
                else
                {
                    current_pwr_state = SYSTEM_LOCKED_OFF;
                }
            }
        }
    }
    else
    {
        power_pressed = 0; // Reset state when released
    }
}
