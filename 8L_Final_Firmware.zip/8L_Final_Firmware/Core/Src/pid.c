/* Core/Src/pid.c */

#include "pid.h"


/* =========================================================
   PID INITIALIZATION
   ========================================================= */

void PID_Init(
    PID_TypeDef *pid,
    float kp,
    float ki,
    float kd
)
{
    pid->Kp = kp;
    pid->Ki = ki;
    pid->Kd = kd;

    pid->Integral = 0.0f;
    pid->Last_Error = 0.0f;
}


/* =========================================================
   PID COMPUTE
   ========================================================= */

int PID_Compute(
    PID_TypeDef *pid,
    float setpoint,
    float current_val
)
{

	    float error;
	    float derivative;
	    float output;

	    const float dt = 0.2f;

    /* Temperature reached */
    if (current_val >= setpoint)
    {
        pid->Integral = 0.0f;
        pid->Last_Error = 0.0f;

        return 0;
    }


    /* Error */
     error = setpoint - current_val;

    /* =====================================================
       INTEGRAL
       ===================================================== */

    pid->Integral += error * dt;

    if (pid->Integral > 500.0f)
    {
        pid->Integral = 500.0f;
    }

    if (pid->Integral < 0.0f)
    {
        pid->Integral = 0.0f;
    }


    /* =====================================================
       DERIVATIVE
       ===================================================== */

    derivative =
        (error - pid->Last_Error) / dt;


    /* =====================================================
       PID OUTPUT
       ===================================================== */

     output =
          (pid->Kp * error)
        + (pid->Ki * pid->Integral)
        + (pid->Kd * derivative);


    pid->Last_Error = error;

    /* Limit PWM */
       if (output > 999.0f)
           output = 999.0f;

       if (output < 0.0f)
           output = 0.0f;


    /* Convert to PWM */
   // int pwm_output = (int)output;





       return (int)output;
}
