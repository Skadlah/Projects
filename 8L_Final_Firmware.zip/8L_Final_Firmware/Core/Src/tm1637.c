#include "tm1637.h"

#define TM1637_I2C_COMM1    0x40
#define TM1637_I2C_COMM2    0xC0
#define TM1637_I2C_COMM3    0x80

// Brightness control: 0x88 (on, lowest) to 0x8F (on, highest). 0x80 is off.
static uint8_t brightness = 0x8F;

// Segment mapping: 0-9
const uint8_t segmentMap[] = {
    0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F
};


// Internal Delay
static void tm1637_delay(void) {
    for (volatile int i = 0; i < 200; i++) {} // Small delay for software I2C
}

static void tm1637_start(void) {
    HAL_GPIO_WritePin(TM1637_DIO_GPIO_Port, TM1637_DIO_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_SET);
    tm1637_delay();
    HAL_GPIO_WritePin(TM1637_DIO_GPIO_Port, TM1637_DIO_Pin, GPIO_PIN_RESET);
    tm1637_delay();
    HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_RESET);
    tm1637_delay();
}

static void tm1637_stop(void) {
    HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_RESET);
    tm1637_delay();
    HAL_GPIO_WritePin(TM1637_DIO_GPIO_Port, TM1637_DIO_Pin, GPIO_PIN_RESET);
    tm1637_delay();
    HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_SET);
    tm1637_delay();
    HAL_GPIO_WritePin(TM1637_DIO_GPIO_Port, TM1637_DIO_Pin, GPIO_PIN_SET);
    tm1637_delay();
}

static void tm1637_writeByte(uint8_t b) {
    for (int i = 0; i < 8; i++) {
        HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_RESET);
        tm1637_delay();
        HAL_GPIO_WritePin(TM1637_DIO_GPIO_Port, TM1637_DIO_Pin, (b & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        tm1637_delay();
        HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_SET);
        tm1637_delay();
        b >>= 1;
    }
    // Wait for ACK
    HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_RESET);
    tm1637_delay();
    HAL_GPIO_WritePin(TM1637_DIO_GPIO_Port, TM1637_DIO_Pin, GPIO_PIN_SET);
    tm1637_delay();
    HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_SET);
    tm1637_delay();
    HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_RESET);
    tm1637_delay();
}

void TM1637_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Ensure GPIOB clock is enabled
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // Configure PB10 and PB11 as Open-Drain Output
    GPIO_InitStruct.Pin = TM1637_CLK_Pin | TM1637_DIO_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    // Default High
    HAL_GPIO_WritePin(TM1637_CLK_GPIO_Port, TM1637_CLK_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(TM1637_DIO_GPIO_Port, TM1637_DIO_Pin, GPIO_PIN_SET);

    TM1637_DisplayOn();
}

void TM1637_DisplaySegments(uint8_t seg0, uint8_t seg1, uint8_t seg2, uint8_t seg3) {
    tm1637_start();
    tm1637_writeByte(TM1637_I2C_COMM1);
    tm1637_stop();

    tm1637_start();
    tm1637_writeByte(TM1637_I2C_COMM2);
    tm1637_writeByte(seg0);
    tm1637_writeByte(seg1);
    tm1637_writeByte(seg2);
    tm1637_writeByte(seg3);
    tm1637_stop();

    tm1637_start();
    tm1637_writeByte(brightness);
    tm1637_stop();
}

void TM1637_DisplayOn(void) {
    brightness = 0x8F; // Max brightness
    tm1637_start();
    tm1637_writeByte(brightness);
    tm1637_stop();
}

void TM1637_DisplayOff(void) {
    brightness = 0x80; // Display off
    tm1637_start();
    tm1637_writeByte(brightness);
    tm1637_stop();
}

void TM1637_DisplayNumber_Internal(int num) {
    uint8_t segments[4] = {0, 0, 0, 0};
    int temp = num;
    if (temp < 0) temp = -temp;

    segments[3] = segmentMap[temp % 10]; temp /= 10;
    segments[2] = temp > 0 || num < 0 ? segmentMap[temp % 10] : 0x00; temp /= 10;
    segments[1] = temp > 0 || num < 0 ? segmentMap[temp % 10] : 0x00; temp /= 10;
    segments[0] = temp > 0 || num < 0 ? segmentMap[temp % 10] : 0x00;

    if (num < 0) {
        if (segments[2] == 0x00) segments[2] = 0x40; // Minus sign
        else if (segments[1] == 0x00) segments[1] = 0x40;
        else segments[0] = 0x40;
    }

    TM1637_DisplaySegments(segments[0], segments[1], segments[2], segments[3]);
}

void TM1637_DisplayTemp_Float(int temp_x10) {
    uint8_t segments[4] = {0, 0, 0, 0};
    int temp = temp_x10;
    if (temp < 0) temp = -temp;

    segments[3] = segmentMap[temp % 10]; temp /= 10;
    segments[2] = segmentMap[temp % 10] | 0x80; // Add decimal point
    temp /= 10;
    segments[1] = (temp > 0 || temp_x10 < 0) ? segmentMap[temp % 10] : 0x00; temp /= 10;
    segments[0] = (temp > 0 || temp_x10 < 0) ? segmentMap[temp % 10] : 0x00;

    if (temp_x10 < 0) {
        if (segments[1] == 0x00) segments[1] = 0x40;
        else segments[0] = 0x40;
    }

    TM1637_DisplaySegments(segments[0], segments[1], segments[2], segments[3]);
}

void TM1637_DisplayHysteresis(float hys_value) {
    int val_x10 = (int)(hys_value * 10.0f);
    TM1637_DisplayTemp_Float(val_x10);
}

void TM1637_Display_Menu_Item(uint8_t f_num, int val_x10, uint8_t is_decimal) {
    uint8_t seg0 = 0x71; // 'F'
    uint8_t seg1 = segmentMap[f_num % 10];
    uint8_t seg2, seg3;

    if (is_decimal) {
        seg3 = segmentMap[val_x10 % 10];
        seg2 = segmentMap[(val_x10 / 10) % 10] | 0x80; // DP
    } else {
        seg3 = segmentMap[val_x10 % 10];
        seg2 = segmentMap[(val_x10 / 10) % 10];
    }

    TM1637_DisplaySegments(seg0, seg1, seg2, seg3);
}
