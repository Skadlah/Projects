################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/ads1115.c \
../Core/Src/buzzer.c \
../Core/Src/compressor.c \
../Core/Src/compressor_pwm.c \
../Core/Src/heater.c \
../Core/Src/led_indicator.c \
../Core/Src/main.c \
../Core/Src/memory_saver.c \
../Core/Src/menu_system.c \
../Core/Src/pid.c \
../Core/Src/stm32f1xx_hal_msp.c \
../Core/Src/stm32f1xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32f1xx.c \
../Core/Src/tm1637.c 

OBJS += \
./Core/Src/ads1115.o \
./Core/Src/buzzer.o \
./Core/Src/compressor.o \
./Core/Src/compressor_pwm.o \
./Core/Src/heater.o \
./Core/Src/led_indicator.o \
./Core/Src/main.o \
./Core/Src/memory_saver.o \
./Core/Src/menu_system.o \
./Core/Src/pid.o \
./Core/Src/stm32f1xx_hal_msp.o \
./Core/Src/stm32f1xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32f1xx.o \
./Core/Src/tm1637.o 

C_DEPS += \
./Core/Src/ads1115.d \
./Core/Src/buzzer.d \
./Core/Src/compressor.d \
./Core/Src/compressor_pwm.d \
./Core/Src/heater.d \
./Core/Src/led_indicator.d \
./Core/Src/main.d \
./Core/Src/memory_saver.d \
./Core/Src/menu_system.d \
./Core/Src/pid.d \
./Core/Src/stm32f1xx_hal_msp.d \
./Core/Src/stm32f1xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32f1xx.d \
./Core/Src/tm1637.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/ads1115.cyclo ./Core/Src/ads1115.d ./Core/Src/ads1115.o ./Core/Src/ads1115.su ./Core/Src/buzzer.cyclo ./Core/Src/buzzer.d ./Core/Src/buzzer.o ./Core/Src/buzzer.su ./Core/Src/compressor.cyclo ./Core/Src/compressor.d ./Core/Src/compressor.o ./Core/Src/compressor.su ./Core/Src/compressor_pwm.cyclo ./Core/Src/compressor_pwm.d ./Core/Src/compressor_pwm.o ./Core/Src/compressor_pwm.su ./Core/Src/heater.cyclo ./Core/Src/heater.d ./Core/Src/heater.o ./Core/Src/heater.su ./Core/Src/led_indicator.cyclo ./Core/Src/led_indicator.d ./Core/Src/led_indicator.o ./Core/Src/led_indicator.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/memory_saver.cyclo ./Core/Src/memory_saver.d ./Core/Src/memory_saver.o ./Core/Src/memory_saver.su ./Core/Src/menu_system.cyclo ./Core/Src/menu_system.d ./Core/Src/menu_system.o ./Core/Src/menu_system.su ./Core/Src/pid.cyclo ./Core/Src/pid.d ./Core/Src/pid.o ./Core/Src/pid.su ./Core/Src/stm32f1xx_hal_msp.cyclo ./Core/Src/stm32f1xx_hal_msp.d ./Core/Src/stm32f1xx_hal_msp.o ./Core/Src/stm32f1xx_hal_msp.su ./Core/Src/stm32f1xx_it.cyclo ./Core/Src/stm32f1xx_it.d ./Core/Src/stm32f1xx_it.o ./Core/Src/stm32f1xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32f1xx.cyclo ./Core/Src/system_stm32f1xx.d ./Core/Src/system_stm32f1xx.o ./Core/Src/system_stm32f1xx.su ./Core/Src/tm1637.cyclo ./Core/Src/tm1637.d ./Core/Src/tm1637.o ./Core/Src/tm1637.su

.PHONY: clean-Core-2f-Src

